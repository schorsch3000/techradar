Please describe your problem, and, if possible, add a small test case.

Issues about licensing are not accepted and immediately closed.
