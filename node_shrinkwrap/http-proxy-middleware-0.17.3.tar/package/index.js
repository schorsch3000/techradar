var HPM  = require('./lib');

module.exports = function(context, opts) {
    return new HPM(context, opts);
};
