# Uniqid Webpack Example
Tested with Webpack 1.13.1.

![Uniqid Webpack Example](http://i.imgur.com/mcYnRac.png)

### Install Webpack
```
npm install webpack -g
```

### Usage
```
webpack ./app.js bundle.js
open index.html
```
