class Test {
  foo() {
    console.log('bar')
    throw new Error('bar')
  }
}
