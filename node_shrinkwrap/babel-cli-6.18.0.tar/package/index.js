throw new Error("Use the `babel-core` package not `babel`.");
