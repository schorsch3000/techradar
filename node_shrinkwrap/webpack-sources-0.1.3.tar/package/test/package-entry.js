describe("package-entry", function() {
	it("should not throw SyntaxError", function() {
		require("../");
	})
});
