define(['Chance', 'mocha', 'chai', 'underscore'], function (Chance, mocha, chai, _) {
    var expect = chai.expect;

    describe("Point", function () {
        var point, chance = new Chance();
        _.noop();

        it("exists", function() {
            expect(chance).to.have.property('point');
        });

        it("looks right", function() {
            _(1000).times(function() {
                point = chance.point();
                expect(point).to.have.property('type');
                expect(point.type).to.equal('Point');
                expect(point).to.have.property('coordinates');
                expect(point.coordinates).to.have.length(2);
                expect(point.coordinates[0]).to.be.within(-180, 180);
                expect(point.coordinates[1]).to.be.within(-90, 90);
            });
        });
    });

    describe("MultiPoint", function () {
        var multipoint, chance = new Chance();

        it("exists", function() {
            expect(chance).to.have.property('multipoint');
        });

        it("looks right", function() {
            _(1000).times(function() {
                multipoint = chance.multipoint();
                console.log(multipoint);
                expect(multipoint).to.have.property('type');
                expect(multipoint.type).to.equal('MultiPoint');
                expect(multipoint).to.have.property('coordinates');
                expect(multipoint.coordinates).to.have.length.within(2, 5);
                expect(multipoint.coordinates[0][0]).to.be.within(-180, 180);
                expect(multipoint.coordinates[0][1]).to.be.within(-90, 90);
            });
        });

        it("throws an error if min > max");
        it("accepts a min and max number of points");
    });
});
