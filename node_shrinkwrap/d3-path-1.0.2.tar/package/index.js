export {default as path} from "./src/path";
